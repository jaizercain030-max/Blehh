(() => {
  const card = document.querySelector('.love-card');
  const buttonArea = document.getElementById('buttonArea');
  const noButton = document.getElementById('noButton');
  const yesButton = document.getElementById('yesButton');
  const promptNote = document.getElementById('promptNote');
  const backdrop = document.getElementById('letterBackdrop');
  const letterModal = document.querySelector('.letter-modal');
  const closeLetter = document.getElementById('closeLetter');
  const confettiLayer = document.getElementById('confettiLayer');

  const playfulMessages = [
    'Are you sure? 🥺',
    'Try again! 💕',
    'Hehe, not that one! ✨',
    'The YES button looks lonely... 🥹',
    'Oops! My heart says YES 💌',
    'Nice try, cutie! 🌷'
  ];
  let dodgeCount = 0;
  let previousFocus = null;

  function dodgeNoButton() {
    const area = buttonArea.getBoundingClientRect();
    const button = noButton.getBoundingClientRect();
    const maxX = Math.max(0, area.width - button.width);
    const maxY = 35;
    const currentLeft = noButton.offsetLeft;
    let nextLeft = currentLeft;
    let nextTop = 0;

    for (let attempt = 0; attempt < 8; attempt += 1) {
      nextLeft = Math.random() * maxX;
      nextTop = (Math.random() * 2 - 1) * maxY;
      if (Math.abs(nextLeft - currentLeft) > Math.min(44, maxX / 2)) break;
    }

    noButton.style.position = 'absolute';
    noButton.style.left = `${nextLeft}px`;
    noButton.style.top = `${nextTop}px`;
    noButton.style.transform = `scale(${Math.max(.76, 1 - dodgeCount * .035)}) rotate(${Math.random() * 10 - 5}deg)`;
    promptNote.innerHTML = `${playfulMessages[dodgeCount % playfulMessages.length]} <span>☁️</span>`;
    dodgeCount += 1;
  }

  noButton.addEventListener('pointerenter', dodgeNoButton);
  noButton.addEventListener('focus', dodgeNoButton);
  noButton.addEventListener('click', (event) => {
    event.preventDefault();
    dodgeNoButton();
  });

  // On touch screens there is no hover, so the first tap gives the button a chance to escape.
  noButton.addEventListener('touchstart', (event) => {
    event.preventDefault();
    dodgeNoButton();
  }, { passive: false });

  function celebrate() {
    const symbols = ['♥', '♡', '✦', '✿', '💕', '✨'];
    for (let index = 0; index < 34; index += 1) {
      const piece = document.createElement('span');
      piece.className = 'confetti-piece';
      piece.textContent = symbols[Math.floor(Math.random() * symbols.length)];
      piece.style.left = `${Math.random() * 100}%`;
      piece.style.setProperty('--duration', `${2.1 + Math.random() * 2.2}s`);
      piece.style.setProperty('--drift', `${Math.random() * 180 - 90}px`);
      piece.style.fontSize = `${12 + Math.random() * 17}px`;
      piece.style.animationDelay = `${Math.random() * .7}s`;
      confettiLayer.appendChild(piece);
      piece.addEventListener('animationend', () => piece.remove(), { once: true });
    }
  }

  function openLetter() {
    previousFocus = document.activeElement;
    card.classList.add('is-opening');
    yesButton.disabled = true;
    noButton.disabled = true;
    celebrate();
    window.setTimeout(() => {
      backdrop.hidden = false;
      letterModal.focus();
      closeLetter.focus();
    }, 620);
  }

  function hideLetter() {
    backdrop.hidden = true;
    card.classList.remove('is-opening');
    yesButton.disabled = false;
    noButton.disabled = false;
    if (previousFocus) previousFocus.focus();
  }

  yesButton.addEventListener('click', openLetter);
  closeLetter.addEventListener('click', hideLetter);
  backdrop.addEventListener('click', (event) => {
    if (event.target === backdrop) hideLetter();
  });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && !backdrop.hidden) hideLetter();
  });
})();
